<?php 
echo "题目在hijack.php中"
?>